package chapter.android.aweme.ss.com.homework;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 大作业:实现一个抖音消息页面,所需资源已放在res下面
 */
public class Exercises3 extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tips);
        int[] imageid=new int[]{
                R.drawable.session_robot,R.drawable.icon_girl,R.drawable.icon_girl,
                R.drawable.icon_girl,R.drawable.icon_girl, R.drawable.icon_girl,
                R.drawable.icon_girl,R.drawable.icon_girl,R.drawable.icon_girl,
                R.drawable.icon_girl,R.drawable.icon_girl,R.drawable.icon_girl,
                R.drawable.icon_girl,R.drawable.icon_girl,R.drawable.icon_girl,
                R.drawable.icon_girl,R.drawable.icon_girl,R.drawable.icon_girl,
                R.drawable.icon_girl

        };
        String[] title=new String[]{
                "aa","bb","cc","dd","ee","ff","gg","hh","ii","jj","kk","ll","mm",
                "nn","oo","pp","qq","rr","ss"
        };
        List<Map<String,Object>> listitem=new ArrayList<Map<String,Object>>();
        for(int i=0;i<imageid.length;i++){
            Map<String,Object> map=new HashMap<String, Object>();
            map.put("image",imageid[i]);
            map.put("name",title[i]);
            listitem.add(map);
        }
        SimpleAdapter adapter=new SimpleAdapter(this,listitem,R.layout.main,new String[]{"name","image"},
                new int[]{R.id.title,R.id.image});
        ListView listView=(ListView)findViewById(R.id.listview1);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent,View view,int position,long id){
                Map<String,Object> map=(Map<String, Object>) parent.getItemAtPosition(position);
                Toast.makeText(Exercises3.this, map.get("name").toString(),Toast.LENGTH_LONG).show();

            }
        });
    }

}
